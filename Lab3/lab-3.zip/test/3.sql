.headers on
--What is the address, phone number, and account balance of “Customer#000000227”?
SELECT c_address, c_phone, c_acctbal from customer where c_name = 'Customer#000000227';